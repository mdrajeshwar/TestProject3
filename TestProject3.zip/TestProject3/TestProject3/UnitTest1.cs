using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.DevTools.V125.SystemInfo;

namespace TestProject3
{
    public class Tests
    {
        IWebDriver driver = new ChromeDriver();
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
           
            driver.Navigate().GoToUrl("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
            driver.Manage().Window.Maximize();
            Thread.Sleep(1000);
            var s = driver.FindElement(By.XPath("//p[@class='oxd-text oxd-text--p'][1]")).Text;
            var username1 = s.Split(":")[1].Trim();

            Console.WriteLine(username1);
            var p = driver.FindElement(By.XPath("//p[@class='oxd-text oxd-text--p'][2]")).Text;
            var password2 = p.Split(":")[1].Trim();

            Console.WriteLine(password2);

            Thread.Sleep(1000);
            IWebElement UserTextField = driver.FindElement(By.XPath("//input[@name='username']"));
            UserTextField.SendKeys(username1);

            IWebElement PassWordField = driver.FindElement(By.XPath("//input[@name='password']"));
            PassWordField.SendKeys(password2);

            IWebElement Login = driver.FindElement(By.XPath("//button[@type='submit']"));

            Login.Click();
            Thread.Sleep(5000);

            IWebElement ClickOnAdmin = driver.FindElement(By.XPath("//span[text()='Admin']"));
            ClickOnAdmin.Click();

            Thread.Sleep(2000);

            IWebElement EditUser = driver.FindElement(By.XPath("(//i[@class='oxd-icon bi-pencil-fill'])[2]"));
            EditUser.Click();
            Thread.Sleep(3000);
            String UserRoleS = "//label[contains(., 'User Role')]//following::div[1]//div[@class='oxd-select-text-input']";
            IWebElement UserRole = driver.FindElement(By.XPath(UserRoleS));
            UserRole.Click();
            Thread.Sleep(3000);
            var se = driver.FindElements(By.XPath("//*[@role='listbox']//div[not(contains(@class, 'oxd-select-option --'))]"));
            // Thread.Sleep(5000);

            foreach (var item in se)
            {
                Console.WriteLine(item.Text);
                if (item.Text != "-- Select --")
                {
                    item.Click();

                    Thread.Sleep(5000);
                    driver.FindElement(By.XPath("//button[@type='submit']")).Click();
                }
                else { 
                
                }

                try
                {
                    ClickOnAdmin = driver.FindElement(By.XPath("//span[text()='Admin']"));
                    ClickOnAdmin.Click();

                }
                catch (Exception)
                {

                    throw;
                }
                Thread.Sleep(5000);

                Screenshot ss = ((ITakesScreenshot)driver).GetScreenshot();

                ss.SaveAsFile("filename.png");

                
            }







        }
        [TearDown]
        public void TearDown()
        {
            driver.Quit();
            
        }
    }
}